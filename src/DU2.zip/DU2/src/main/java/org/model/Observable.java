package org.model;

public interface Observable {
    void addPerson (User user);
}
