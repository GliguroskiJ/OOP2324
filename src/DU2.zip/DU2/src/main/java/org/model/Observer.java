package org.model;

public interface Observer {
    void notifyAboutPost (Post post);
}
